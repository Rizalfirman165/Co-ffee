package com.rizalfirman.co_ffee.di

object Injection {

//    fun prediction(): Repository{
//        val apiService = ApiConfig.getApiService()
//        return Repository.getInstance(apiService)
//    }
}