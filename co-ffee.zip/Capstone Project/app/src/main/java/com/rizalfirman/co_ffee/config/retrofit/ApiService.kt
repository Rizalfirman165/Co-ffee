package com.rizalfirman.co_ffee.config.retrofit

import com.rizalfirman.co_ffee.config.repo.Response
import okhttp3.MultipartBody
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part

interface ApiService {


    @POST("predict")
    @Multipart
    suspend fun diagnose(
        @Part file: MultipartBody.Part,

    ): Response

}