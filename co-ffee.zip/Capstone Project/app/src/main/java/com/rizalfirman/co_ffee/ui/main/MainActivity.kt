package com.rizalfirman.co_ffee.ui.main

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Menu
import android.view.MenuItem
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.appbar.MaterialToolbar
import com.rizalfirman.co_ffee.R
import com.rizalfirman.co_ffee.databinding.ActivityMainBinding
import com.rizalfirman.co_ffee.ui.deteksi.DeteksiActivity
import com.rizalfirman.co_ffee.ui.list.ListActivity

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        binding = ActivityMainBinding.inflate(layoutInflater)
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        binding.deteksi.setOnClickListener {
            intent = Intent(this, DeteksiActivity::class.java)
            startActivity(intent)
            finish()
        }
        binding.daftar.setOnClickListener {
            intent = Intent(this, ListActivity::class.java)
            startActivity(intent)
            finish()
        }

        val toolbar = findViewById<MaterialToolbar>(R.id.topBar)
        setSupportActionBar(toolbar)
        supportActionBar?.title = resources.getString(R.string.dashboard)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val inflater = menuInflater
        inflater.inflate(R.menu.menu_setting, menu)
        return true
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId){
            R.id.action_setting -> {
                startActivity(Intent(Settings.ACTION_LOCALE_SETTINGS))
                true
            }
            else -> true
        }
    }
}